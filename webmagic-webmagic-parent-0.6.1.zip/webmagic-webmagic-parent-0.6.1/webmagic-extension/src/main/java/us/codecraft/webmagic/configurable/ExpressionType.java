package us.codecraft.webmagic.configurable;

/**
 * @author code4crafter@gmail.com
 */
public enum ExpressionType {

    XPath, Regex, Css, JsonPath;

}
